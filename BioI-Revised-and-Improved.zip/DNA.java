import java.util.Arrays;
import java.util.Scanner;

class DNA{
  private String[] strand1; // main strand of DNA
  private String[] strand2; // complementary base pairs
  private int length1; // user inputted length
  public int random; // random int for creating DNA strand
  private String seq; // user inputted sequence
  private String strand1String; // strand1 turned into a string for the purpose of the loop
  
  public DNA(){
    Scanner kb = new Scanner(System.in);
    System.out.print("How long would you like the DNA strand to be? ");
    length1 = kb.nextInt();
    strand1 = new String[length1];
    for(int i = 0; i < strand1.length; i++){
       random = (int)((Math.random() * 4) + 1);
       if(random == 1)
          strand1[i] = "A";
       if(random == 2)
          strand1[i] = "T";
       if(random == 3)
          strand1[i] = "C";
       if(random == 4)
          strand1[i] = "G";
    }
  }

  public static String getPair(int i, String[] strand1){
    if(strand1[i].equals("A"))
        return "T";
      if(strand1[i].equals("T"))
        return "A";
      if(strand1[i].equals("C"))
        return "G";
      if(strand1[i].equals("G"))
        return "C";
      return "";
  }

  public void pairDNA(){
    String[] strand2 = new String[strand1.length];
    for(int i = 0; i < strand2.length; i++)
      strand2[i] = getPair(i, strand1);
  }

  public void printDNA(){
    for(int i = 0; i < strand1.length; i++)
      System.out.println(strand1[i] + " - " + getPair(i, strand1));
    }

  public void getNumSequence(){
    Scanner kb = new Scanner(System.in);
    int count = 0;
    System.out.print("Enter Desired Sequence: ");
    seq = kb.next();
    seq = seq.toUpperCase();
    strand1String = "";

    for(int i = 0; i < strand1.length; i++)
      strand1String += strand1[i];

    for(int i = 0; i < strand1String.length() - seq.length(); i++){
      if(strand1String.substring(i, i + seq.length()).equals(seq))
        count++;
    }
     System.out.println("Sequence " + seq + " appears in Strand1 " + count + " times.");
  }
}