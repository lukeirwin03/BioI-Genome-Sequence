class Main {
  public static void main(String[] args) {
    DNA DNA1 = new DNA(); // constructor for the DNA strand

    DNA1.pairDNA(); // creates a list of the complementary base pairs
    
    DNA1.printDNA(); // prints the DNA strand

    DNA1.getNumSequence(); // returns the number of times the sequence appears in the DNA segment
    System.out.println(DNA1); // calls the toString to print
  }
}